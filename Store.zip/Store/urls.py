from django.urls import path
from .views import signup, home, login, showproducts, cart, checkout, orders, review
from .views.login import logout


urlpatterns = [
    path('signup', signup.Signup.as_view(), name='signup'),
    path('', home.homeview, name="Home"),
    path('login', login.Login.as_view(), name='login'),
    path('product', showproducts.Showproducts.as_view(), name='viewproducts'),
    path('logout', logout, name='logout'),
    path('cart', cart.Cart.as_view(), name='cart'),
    path('checkout', checkout.Checkout.as_view()),
    path('process_payment', checkout.process_payment, name='process_payment'),
    path('process_payment', checkout.paytm),
    #path('paytm', checkout.Checkout.as_view(), name='paytm'),
    path('paytm', checkout.paytm, name='paytm'),
    path('paymentstatus', checkout.handlerequest, name='paymentstatus'),
    path('payment_done', checkout.postpayment.as_view()),
    path('payment_done', checkout.payment_done, name='payment_done'),
    path('orders', orders.OrderView.as_view(), name='orders'),
    path('payment_cancelled', checkout.payment_canceled, name='payment_cancelled'),
    path('productdetail', showproducts.ProductDetail.as_view(), name='productdetail'),
    #path('productdetail', review.AddReview)
    #path('productdetail', showproducts.AddReview)
]