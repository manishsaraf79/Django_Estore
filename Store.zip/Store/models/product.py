from django.db import models
from .category import Category
from .subcategory import Subcategory


class Product(models.Model):
    name = models.CharField(max_length=50)
    price = models.IntegerField(default=0)
    category = models.ForeignKey(Category, on_delete=models.CASCADE, default=1)
    subcategory = models.ForeignKey(Subcategory, on_delete=models.CASCADE, null=True, blank=True)
    description = models.CharField(max_length=200, default="", null=True, blank=True)
    detail = models.CharField(max_length=5000, default="", null=True, blank=True)
    image = models.ImageField(upload_to='uploads/products/')
    new = models.BooleanField(default=False)

    @staticmethod
    def get_cartproducts_by_id(ids):
        return Product.objects.filter(id__in=ids)

    @staticmethod
    def get_all_products():
        return Product.objects.all()

    @staticmethod
    def get_all_products_byid(categoryid):
        if categoryid:
            return Product.objects.filter(category=categoryid)

    @staticmethod
    def get_all_products_byidsub(categoryid):
        if categoryid:
            return Product.objects.filter(category=categoryid)

    def get_subcategories_bycateid(categoryid):
        return Product.objects.filter(category=categoryid).values('subcategory').distinct()