from django.shortcuts import render, redirect
from django.views import View
from Store.models.product import Product


class Cart(View):
    removeid = None

    def get(self, request):
        error_msg = None
        try:
            customer = request.session.get('customer')
            ids = (list(request.session.get('cart').keys()))
            products = Product.get_cartproducts_by_id(ids)
            if not request.session:
                error_msg = "The cart is empty!!"
            elif not request.session.get('cart').keys():
                error_msg = "The cart is empty!!"
            params = {'cartproducts': products, 'customer': customer, 'error': error_msg}
            return render(request, 'cart.html', params)
        except:
            error_msg = "The cart is empty!!"
            return render(request, 'cart.html', {'error': error_msg})

    def post(self, request):
        product = request.POST.get('product')
        remove = request.POST.get('remove')
        delid = request.POST.get('removeid')
        cart = request.session.get('cart')
        quantity = cart.get(product)

        if delid:
            cart.pop(delid)
        elif remove:
            if quantity <= 1:
                cart.pop(product)
            else:
                cart[product] = quantity - 1
        else:
            cart[product] = quantity + 1

        request.session['cart'] = cart

        return redirect('cart')
