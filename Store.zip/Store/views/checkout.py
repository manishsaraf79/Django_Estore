from django.shortcuts import render, redirect, HttpResponseRedirect
from django.urls import reverse
from django.conf import settings
import shortuuid
from paypal.standard.forms import PayPalPaymentsForm
from django.views.decorators.csrf import csrf_exempt
from django.views import View
from Store.models.product import Product
from Store.models.customer import Customer
from Store.models.orders import Order
from Store.models.states import State
from Store.templatetags.cart import total_cart_price
from Store.PayTm import Checksum

MERCHANT_KEY = 'kbzk1DSbJiV_O3p5';
def process_payment(request):
    customer = request.session.get('customer')
    ids = (list(request.session.get('cart').keys()))
    products = Product.get_cartproducts_by_id(ids)
    global tp
    tp = total_cart_price(products, request.session.get('cart'))
    names = []
    for product in products:
        names.append(product.name)
    host = request.get_host()

    paypal_dict = {
        'business': settings.PAYPAL_RECEIVER_EMAIL,
        'amount': tp,
        'item_name': names,
        'currency_code': 'USD',
        'notify_url': 'http://{}{}'.format(host,
                                           reverse('paypal-ipn')),
        'return_url': 'http://{}{}'.format(host,
                                           reverse('payment_done')),
        'cancel_return': 'http://{}{}'.format(host,
                                              reverse('payment_cancelled')),
    }

    form = PayPalPaymentsForm(initial=paypal_dict)
    return render(request, 'process_payment.html', {'tp': tp, 'names': names, 'form': form})


@csrf_exempt
def payment_done(request):
     return render(request, 'payment_done.html')


@csrf_exempt
def payment_canceled(request):
    return render(request, 'payment_cancelled.html')


class Checkout(View):
    def get(self, request):
        state = State.get_all_states()
        params = {'states': state}
        return render(request, 'checkout.html', params)

    def post(self, request):
        global address
        global address2
        global city
        global state
        global zip
        global phone
        ids = (list(request.session.get('cart').keys()))
        products = Product.get_cartproducts_by_id(ids)
        tp = total_cart_price(products, request.session.get('cart'))
        address = request.POST.get('address')
        address2 = request.POST.get('address2')
        city = request.POST.get('city')
        state = request.POST.get('state')
        zip = request.POST.get('zip')
        phone = request.POST.get('phone')
        value = {'address': address, 'address2': address2, 'city': city, 'state': state, 'zip': zip, 'phone': phone}
        error_message = None
        if not address:
            error_message = "Address required"
        elif not city:
            error_message = "City required"
        elif not state:
            error_message = "State required"

        if not error_message:
            #return redirect('process_payment')
            global order_id
            email = request.session.get('email')
            order = shortuuid.uuid()
            order_id = order[:5]
            host = request.get_host()
            print(order_id)
            ids = (list(request.session.get('cart').keys()))
            cart = request.session.get('cart')
            products = Product.get_cartproducts_by_id(ids)
            customer = request.session.get('customer')
            for product in products:
                order = Order(order_id=order_id,
                              customer=Customer(id=customer),
                              product=product,
                              price=product.price,
                              address=address,
                              address2=address2,
                              city=city,
                              state=state,
                              zip=zip,
                              phone=phone,
                              quantity=cart.get(str(product.id)))
                order.placeOrder()
            param_dict = {
                'MID': 'WorldP64425807474247',
                'ORDER_ID': order_id,
                'CUST_ID': email,
                'TXN_AMOUNT': str(tp),
                'INDUSTRY_TYPE_ID': 'Retail',
                'WEBSITE': 'WEBSTAGING',
                'CHANNEL_ID': 'WEB',
                'CALLBACK_URL': 'http://{}{}'.format(host,
                                           reverse('paymentstatus')),
            }
            print(param_dict)
            param_dict['CHECKSUMHASH'] = Checksum.generate_checksum(param_dict, MERCHANT_KEY)
            return render(request, 'paytm.html', {'param_dict': param_dict})

        else:
            state = State.get_all_states()
            return render(request, 'checkout.html', {'error': error_message, 'values': value, 'states': state})



class postpayment(View):
    def get(self, request):
        Checkout()
        ids = (list(request.session.get('cart').keys()))
        cart = request.session.get('cart')
        products = Product.get_cartproducts_by_id(ids)
        customer = request.session.get('customer')
        for product in products:
            order = Order(customer=Customer(id=customer),
                          product=product,
                          price=product.price,
                          address=address,
                          address2=address2,
                          city=city,
                          state=state,
                          zip=zip,
                          phone=phone,
                          quantity=cart.get(str(product.id)))
            order.placeOrder()
        request.session['cart'] = {}
        return render(request, 'payment_done.html')


@csrf_exempt
def handlerequest(request):
    global checksum
    print(request.session.get('email'))
    form = request.POST
    response_dict = {}
    for i in form.keys():
        response_dict[i] = form[i]
        if i == 'CHECKSUMHASH':
            checksum = form[i]
    verify = Checksum.verify_checksum(response_dict, MERCHANT_KEY, checksum)
    if verify:
        if response_dict['RESPCODE'] == '01':
            rows = Order.objects.filter(order_id=order_id)
            print(rows)
            request.session['cart'] = {}
            print("Order Successful")

        else:
            rows = Order.objects.filter(order_id=order_id)
            print(rows)
            rows.delete()
            print("Order was not successful")
    return render(request, 'paymentstatus.html', {'response': response_dict})
