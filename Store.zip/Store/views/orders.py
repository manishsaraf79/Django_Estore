from django.shortcuts import render, redirect
from django.views import View
from Store.models.orders import Order

class OrderView(View):
    def get(self,request):
        customer = request.session.get('customer')
        orders = Order.get_orders_by_customer(customer)
        params = {'orders': orders}
        return render(request, 'orders.html', params)