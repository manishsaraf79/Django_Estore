from django.shortcuts import render, HttpResponseRedirect
from Store.models.customer import Customer
from Store.models.review import Review


def AddReview(request):
    email = request.session.get('email')
    customer = Customer.get_customer_by_email(email).firstname
    returnurl = request.GET.get('addreview')
    productID = request.GET.get('gettid')
    review = request.POST.get('review')
    rating = request.POST.get('rating')
    if review:
        reviews = Review(product=productID,
                         customername=customer,
                         reviews=review,
                         rating=rating)
        reviews.addReview()
        return HttpResponseRedirect(returnurl)
    return render(request, 'productdetail.html')
