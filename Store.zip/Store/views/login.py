from django.shortcuts import render, redirect, HttpResponseRedirect
from django.contrib.auth.hashers import check_password
from django.views import View
from Store.models.customer import Customer


class Login(View):
    url=None
    reviewurl = None
    def get(self, request):
        Login.url = request.GET.get('next')
        Login.reviewurl = request.GET.get('getreview')
        return render(request, 'login.html')

    def post(self, request):
        email = request.POST.get('email')
        password = request.POST.get('password')
        customer = Customer.get_customer_by_email(email)
        error_message = None
        if customer:
            flag = check_password(password, customer.password)
            if flag:
                request.session['customer'] = customer.id
                request.session['email'] = customer.email
                request.session.modified = True
                if Login.url:
                    return HttpResponseRedirect(Login.url)
                if Login.reviewurl:
                    return HttpResponseRedirect(Login.reviewurl)
                else:
                    return redirect('viewproducts')
            else:
                error_message = "Email or Password is not valid!!"
        else:
            error_message = "Email or Password is not valid!!"

        return render(request, 'login.html', {'error': error_message})


def logout(request):
    request.session.clear()
    return redirect('login')
