from django.shortcuts import render
from Store.models.category import Category
from Store.models.product import Product
from Store.models.carouselimage import Carouselimage

def homeview(request):
    categories = Category.get_all_products()
    prods = Product.get_all_products()
    images = Carouselimage.get_all_images()
    params = {'products': images, 'newprods': prods, 'featured':categories}
    return render(request, 'home.html', params)