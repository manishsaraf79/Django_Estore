from .models.category import Category
from .models.customer import Customer

def get_customer(request):
    categos = Category.get_all_products()
    email = request.session.get('email')

    if email:
        customer = Customer.get_customer_by_email(email).firstname
        return{'customername': customer, 'categories': categos}
    else:
        return {'categories': categos}
